require('./bootstrap');

window.Swal = require('sweetalert2');